# Web-Development-POE



Copy the masinyusaneWeb folder to desktop in order to run it on your browser. It will not function if opened straight from GitHub.



References:

• http://www.masinyusane.org

• http://www.heraldlive.co.za

• http://www.algoafm.co.za/algoa-cares/masinyusane-development-organisation

• http://www.hosting24.co.za/web-hosting-packages

• http://www.mcloud9.co.za/blog/breaking-down-website-hosting-costs

• https://www.reddit.com/r/southafrica/comments/vnas9z

IMAGES:

Masinyusane(n.d) Photo of Jim Mckeown and Fiks Mahola.Available at:

https://www.masinyusane.org (accessed 26 august 2025)

Masinyusane.(n.d). Organisation logo.Masinyusane.https://www.masinyusane.org



Changes made:\*added the links for the images used in the website

